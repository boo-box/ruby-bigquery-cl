require File.dirname(__FILE__) + '/test_helper.rb'

class TestRubyBigqueryCl < Test::Unit::TestCase

  def setup
  end
  
  def test_truth
    assert true
  end
end
